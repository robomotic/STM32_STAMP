Gerber file extensions:

*.TOP = Top Layer
*.BOT = Bottom Layer
*.SMT = Soldermask Top
*.SMB = Soldermask Bottom
*.SPT = Solder Paste Top
*.SPB = Solder Paste Bottom
*.SST = Silkscreen Top
*.SSB = Silkscreen Bottom
*.AST = Assembly Top
*.ASB = Assembly Bottom
*.DRD = Drill Drawing

Not gerber files:
*.DTS = Drill Tape Summary Report
*.GTD = OrCAD file
*.LIS = postprocessing report 
*.TAP = drill file

